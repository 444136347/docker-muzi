Install instructions are at:  https://www.chilkatsoft.com/installPhpExtension.asp 
also see https://www.chilkatsoft.com/php.asp#debianInstall for apt-get installs for Debian/Ubuntu.

Reference Documentation: https://www.chilkatsoft.com/refdoc/php.asp
Sample Code: https://www.example-code.com/php/default.asp
Chilkat Blog: http://www.cknotes.com/
Purchase/Prices: https://www.chilkatsoft.com/purchase2.asp
