
extern zend_class_entry *phalcon_db_enum_ce;

ZEPHIR_INIT_CLASS(Phalcon_Db_Enum);

